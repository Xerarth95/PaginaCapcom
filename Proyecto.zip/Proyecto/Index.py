from pickle import TRUE
from flask import Flask, render_template, request
from pymongo import MongoClient
import pymongo


MONGO_USER="AC1904"
MONGO_PASS="Tuity15"
MONGO_TIEMPO_FUERA=1000
mongo_uri="mongodb+srv://"+MONGO_USER+":"+MONGO_PASS+"@databasenosql.d6kk5u7.mongodb.net/?retryWrites=true&w=majority"

MONGO_BASEDATOS="OsaResort"
MONGO_COLECCION="Clientes"

cliente=MongoClient(mongo_uri,serverSelectionTimeoutMS=MONGO_TIEMPO_FUERA)
basedatos=cliente[MONGO_BASEDATOS]
coleccion=basedatos[MONGO_COLECCION]

app = Flask(__name__)

@app.route('/')
def ingreso():
    return render_template('ingreso.html')

@app.route('/principal')
def principal():
    return render_template('principal.html')

@app.route('/reservaciones')
def reservaciones():
    return render_template('reservaciones.html')

@app.route('/actividades')
def actividades():
    actividades= ("Paseos en Caballo", "Caminatas", "Paseo en Balsa")
    return render_template('actividades.html', actividades=actividades)

@app.route('/clientes')
def clientes():
        clientes = coleccion.find()
        return render_template('clientes.html', clientes=clientes)


@app.route('/identificacion', methods=['POST'])
def identificacion():
    correo = request.form['correo']
    contrasena = request.form['contrasena']
    results = coleccion.find({'correo': correo, 'contrasena': contrasena})
    try:
        for resultado in results:
            if resultado['nombre'] is None:
                print('User not exists.')
                return render_template('ingreso.html')
            else:
                print(results)
                return render_template('principal.html')
    except pymongo.errors.ConectionFailure as error:
            print(error) 

if __name__ == '__main__':
    app.run(debug=TRUE)